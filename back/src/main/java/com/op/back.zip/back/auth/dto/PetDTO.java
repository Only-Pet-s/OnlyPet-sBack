package com.op.back.auth.dto;

import lombok.Data;

@Data
public class PetDTO {
    private String animalName;
    private String birthday;
}
