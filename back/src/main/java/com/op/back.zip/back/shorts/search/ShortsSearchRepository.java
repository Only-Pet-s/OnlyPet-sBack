package com.op.back.shorts.search;

import java.util.List;

import org.springframework.stereotype.Repository;

import co.elastic.clients.elasticsearch.ElasticsearchClient;
import co.elastic.clients.elasticsearch.core.SearchResponse;
import lombok.RequiredArgsConstructor;

@Repository
@RequiredArgsConstructor
public class ShortsSearchRepository {

    private final ElasticsearchClient client;

    private static final String INDEX = "shorts";

    public List<ShortsDocument> search(String keyword) {
        try {
            SearchResponse<ShortsDocument> response = client.search(
                s -> s
                    .index(INDEX)
                    .query(q -> q
                        .match(m -> m
                            .field("description")
                            .query(keyword)
                        )
                    ),
                ShortsDocument.class
            );

            return response.hits().hits().stream()
                    .map(hit -> hit.source())
                    .toList();

        } catch (Exception e) {
            throw new RuntimeException("Shorts search failed", e);
        }
    }
}