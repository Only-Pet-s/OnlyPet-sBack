package com.op.back.shorts.search;

import java.time.Instant;
import java.util.List;

import lombok.Data;

@Data
public class ShortsDocument {

    private String id;
    private String uid;

    private String description;
    private List<String> hashtags;

    private int viewCount;
    private Instant createdAt;
}